'use strict';

module.exports = function(Facturae) {

};
