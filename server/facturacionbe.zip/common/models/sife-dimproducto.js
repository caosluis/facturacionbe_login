'use strict';

module.exports = function(Sifedimproducto) {
    
    Sifedimproducto.observe('before save', function(ctx, next) {
        //const utf8 = require('utf8');
        //console.log('> before save triggered:', ctx.Model.modelName, ctx.instance );
         //if(ctx.instance.Producto != null){
         //    ctx.instance.Producto = utf8.encode(ctx.instance.Producto.trim());
         //}
         //if(ctx.instance.IdProdFabrica != null){
         //    ctx.instance.IdProdFabrica = utf8.encode(ctx.instance.IdProdFabrica.trim());
         //}
         //if(ctx.instance.IdProdConso != null){
         //   ctx.instance.IdProdConso = utf8.encode(ctx.instance.IdProdConso.trim());
         //}
         //if(ctx.instance.IdProdSBO != null){
         //    ctx.instance.IdProdSBO = utf8.encode(ctx.instance.IdProdSBO.trim());
         //}
        next();
      });
};
