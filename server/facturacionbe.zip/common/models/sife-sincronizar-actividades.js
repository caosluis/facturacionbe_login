'use strict';

module.exports = function(Sifesincronizaractividades) {

};
