'use strict';

module.exports = function(Sifeproductos) {

};
