'use strict';

module.exports = function(Sifeproductossector) {

};
