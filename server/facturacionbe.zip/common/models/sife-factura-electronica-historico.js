'use strict';

module.exports = function(Sifefacturaelectronicahistorico) {

};
