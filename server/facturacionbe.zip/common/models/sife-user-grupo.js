'use strict';

module.exports = function(Sifeusergrupo) {

};
