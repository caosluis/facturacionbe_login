'use strict';

module.exports = function(Sifesincronizarparametricapaisorigen) {

};
