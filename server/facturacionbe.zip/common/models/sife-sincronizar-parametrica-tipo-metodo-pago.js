'use strict';

module.exports = function(Sifesincronizarparametricatipometodopago) {

};
