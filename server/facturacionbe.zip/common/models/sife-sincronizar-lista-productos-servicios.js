'use strict';

module.exports = function(Sifesincronizarlistaproductosservicios) {

};
