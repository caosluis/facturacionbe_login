'use strict';

module.exports = function(Sifefechahorah) {

};
