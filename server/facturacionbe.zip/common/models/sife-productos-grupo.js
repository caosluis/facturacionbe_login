'use strict';

module.exports = function(Sifeproductosgrupo) {

};
