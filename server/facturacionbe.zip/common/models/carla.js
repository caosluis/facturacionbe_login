'use strict';

module.exports = function(Carla) {

};
