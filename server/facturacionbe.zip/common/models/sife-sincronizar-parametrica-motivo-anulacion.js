'use strict';

module.exports = function(Sifesincronizarparametricamotivoanulacion) {

};
