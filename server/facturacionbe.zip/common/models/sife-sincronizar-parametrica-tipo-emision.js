'use strict';

module.exports = function(Sifesincronizarparametricatipoemision) {

};
