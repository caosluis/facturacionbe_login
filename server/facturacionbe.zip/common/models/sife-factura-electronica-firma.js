'use strict';

module.exports = function(Sifefacturaelectronicafirma) {

};
