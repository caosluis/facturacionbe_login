'use strict';

module.exports = function(Sifesincronizarparametricatipodocumentoidentidad) {

};
