'use strict';

module.exports = function(Sincronizarlistaleyendasfactura) {

};
