'use strict';

module.exports = function(Sifesincronizarparametricaeventossignificativos) {

};
