'use strict';

module.exports = function(Sifefacturaelectronicaestadohistorico) {

};
