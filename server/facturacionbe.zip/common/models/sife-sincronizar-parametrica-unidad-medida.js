'use strict';

module.exports = function(Sifesincronizarparametricaunidadmedida) {

};
