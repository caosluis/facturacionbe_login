'use strict';

module.exports = function(Sifeproductossubgrupo) {

};
