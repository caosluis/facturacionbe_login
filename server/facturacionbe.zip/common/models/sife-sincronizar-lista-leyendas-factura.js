'use strict';

module.exports = function(Sifesincronizarlistaleyendasfactura) {

};
