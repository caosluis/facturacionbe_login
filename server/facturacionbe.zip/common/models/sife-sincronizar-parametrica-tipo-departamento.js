'use strict';

module.exports = function(Sifesincronizarparametricatipodepartamento) {

};
