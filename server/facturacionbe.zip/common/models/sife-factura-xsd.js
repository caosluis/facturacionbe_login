'use strict';

module.exports = function(Sifefacturaxsd) {

};
