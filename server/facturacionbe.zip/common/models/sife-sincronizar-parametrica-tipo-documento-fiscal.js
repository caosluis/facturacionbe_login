'use strict';

module.exports = function(Sifesincronizarparametricatipodocumentofiscal) {

};
