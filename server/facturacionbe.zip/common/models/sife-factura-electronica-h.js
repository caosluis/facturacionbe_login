'use strict';

module.exports = function(Sifefacturaelectronicah) {

};
