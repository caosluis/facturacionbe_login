'use strict';

module.exports = function(Sifesincronizarh) {

};
