'use strict';

module.exports = function(Sifecufdh) {

};
