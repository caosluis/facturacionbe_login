'use strict';

module.exports = function(Sifefacturaelectronica) {

};
