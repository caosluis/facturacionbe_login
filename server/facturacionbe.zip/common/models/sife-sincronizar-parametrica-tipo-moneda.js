'use strict';

module.exports = function(Sifesincronizarparametricatipomoneda) {

};
