'use strict';

module.exports = function(Sifesincronizarlistamensajesservicios) {

};
