'use strict';

module.exports = function(Sifeproductosfamilia) {

};
