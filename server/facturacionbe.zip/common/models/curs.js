'use strict';

module.exports = function(Curs) {

};
