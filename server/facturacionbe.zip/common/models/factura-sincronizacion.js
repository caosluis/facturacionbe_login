'use strict';

module.exports = function(Facturasincronizacion) {

};
