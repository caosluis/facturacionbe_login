'use strict';

module.exports = function(Sifesincronizarparametricatipopuntoventa) {

};
