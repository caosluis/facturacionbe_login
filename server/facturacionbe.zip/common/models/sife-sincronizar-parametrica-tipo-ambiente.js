'use strict';

module.exports = function(Sifesincronizarparametricatipoambiente) {

};
