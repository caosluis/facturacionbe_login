'use strict';

module.exports = function(Sifefacturaelectronicaview) {

};
