'use strict';

module.exports = function(Catalogo) {

};
