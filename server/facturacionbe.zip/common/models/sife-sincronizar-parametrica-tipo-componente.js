'use strict';

module.exports = function(Sifesincronizarparametricatipocomponente) {

};
