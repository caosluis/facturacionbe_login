'use strict';

module.exports = function(Sincronizarlistamensajesservicios) {

};
