'use strict';

module.exports = function(J) {

};
