'use strict';

module.exports = function(Sifesincronizarparametricatipodocumentosector) {

};
