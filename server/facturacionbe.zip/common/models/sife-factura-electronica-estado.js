'use strict';

module.exports = function(Sifefacturaelectronicaestado) {

};
