'use strict';

module.exports = function(Sifesincronizarparametricatipomodalidad) {

};
