'use strict';

module.exports = function(Sifemodulogrupo) {

};
